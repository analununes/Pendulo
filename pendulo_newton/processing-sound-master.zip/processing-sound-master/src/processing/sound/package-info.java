/**
 * <b>This Javadoc is only provided as reference for advanced users.</b> <b>For the basic documentation of the Processing Sound library with examples, please see <a href="https://processing.org/reference/libraries/sound/" target="_top">https://processing.org/reference/libraries/sound/</a>.</b>
 */
package processing.sound;